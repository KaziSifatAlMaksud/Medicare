<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\MedicalCertificate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class MedicalCertificateController extends Controller
{

    public function index()
    {
        if (Gate::denies('certificate_view')) {
            abort(403, 'Unauthorized action.');
        }

        // Assuming 'status' is a column in your 'medical_certificates' table
        $certificates = MedicalCertificate::where('status', '0')->get();

        return view('superAdmin.certificate.certificate_list', ['certificates' => $certificates]);
    }

    public function send($id)
    {
        $certificate = MedicalCertificate::findOrFail($id);
        $certificate->status = 'send';
        $certificate->save();

        return redirect()->back()->with('success', 'Certificate status updated to "send".');
    }

    public function delete($id)
    {
        $certificate = MedicalCertificate::findOrFail($id);
        $certificate->status = 'delete';
        $certificate->save();

        return redirect()->back()->with('success', 'Certificate status updated to "delete".');
    }
}
