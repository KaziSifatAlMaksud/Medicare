ALTER TABLE `report`
  DROP `pathology_category_id`,
  DROP `radiology_category_id`;
