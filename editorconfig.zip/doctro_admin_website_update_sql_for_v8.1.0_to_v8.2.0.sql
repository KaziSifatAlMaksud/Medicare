-- Add new currency for Kenya and Ghana
INSERT INTO `currency` (`id`, `country`, `currency`, `code`, `symbol`) VALUES (NULL, 'Kenya', 'Kenyan Shilling', 'KES', 'KSh'), (NULL, 'Ghana', 'Ghanaian Cedi', 'GHS', 'GH₵')
