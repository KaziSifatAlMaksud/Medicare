<script src="{{ url('assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ url('assets/js/jquery.min.js') }}"></script>
<script src="{{ url('assets/js/boxicons.js') }}"></script>
@yield('js')
<script src="{{ url('assets/js/slick.min.js') }}"></script>
<script type="text/javascript" src="{{ url('assets_admin/js/datatables.min.js') }}"></script>
<script type="text/javascript" src="{{ url('assets/plugins/fancybox/jquery.fancybox.min.js')}}"></script>
<script src="{{ url('assets/js/app.js') }}"></script>
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-
datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js" integrity="sha512-
GDey37RZAxFkpFeJorEUwNoIbkTwsyC736KNSYucu1WJWFK9qTdzYub8ATxktr6Dwke7nbFai
oypzbDOQykoRg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> --}}
