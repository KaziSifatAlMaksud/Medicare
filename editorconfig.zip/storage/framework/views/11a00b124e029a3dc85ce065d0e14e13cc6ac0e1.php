<!-- resources/views/certificate_index.blade.php -->



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/intlTelInput.css')); ?>" />
    <style>
        /* Your existing styles */
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="bg-green-500 text-white p-4 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('err')): ?>
    <div class="bg-red-500 text-white p-4 rounded mb-4">
        <?php echo e(session('err')); ?>

    </div>
<?php endif; ?>

    <div class="xl:w-3/4 mx-auto">
        <div class="xxsm:mx-5 xl:mx-0 2xl:mx-0 pt-10">
            <div class="flex h-full mb-20 xxsm:flex-col sm:flex-col xmd:flex-row xmd:space-x-5">
                <div class="w-full md:w-full xxmd:w-full xmd:w-80 lg:w-2/3 xlg:w-2/3 1xl:w-full 2xl:w-full sm:ml-0 xxsm:ml-0 shadow-lg overflow-hidden p-5 mt-10 2xl:mt-0 xmd:mt-0">
                    <form action="<?php echo e(route('store.certificate')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <!-- Name Field -->
                        <div class="flex xxsm:flex-col sm:flex-row justify-center w-full">
                            <div class="mb-3 sm:w-1/2 xxsm:w-full">
                                <label for="name" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Name')); ?></label>
                                <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="form-control block w-full font-fira-sans px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="name" placeholder="<?php echo e(__('Name')); ?>" readonly />
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    
                            <!-- Email Field -->
                            <div class="mb-3 sm:w-1/2 xxsm:w-full sm:ml-2 xxsm:ml-0">
                                <label for="email" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Email')); ?></label>
                                <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="email" placeholder="<?php echo e(__('Email')); ?>" readonly />
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    
                        <!-- Phone and Gender Fields -->
                        <div class="flex xxsm:flex-col sm:flex-row justify-center w-full">
                            <div class="mb-3 sm:w-1/2 xxsm:w-full sm:ml-2 xxsm:ml-0">
                                <label for="phone" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Phone Number')); ?></label>
                                <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone_code . ' ' . $user->phone)); ?>" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="phone" placeholder="<?php echo e(__('Phone Number')); ?>" readonly />
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    
                            <div class="mb-3 sm:w-1/2 xxsm:w-full sm:ml-2 xxsm:ml-0">
                                <label for="gender" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Gender')); ?></label>
                                <input type="text" name="gender" value="<?php echo e(old('gender', $user->gender)); ?>" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="gender" placeholder="<?php echo e(__('Gender')); ?>" readonly />
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    
                        <!-- Language and Prescription Fields -->
                        <div class="flex xxsm:flex-col sm:flex-row justify-center w-full">
                            <div class="mb-3 sm:w-1/2 xxsm:w-full sm:ml-2 xxsm:ml-0">
                                <label for="language" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Language')); ?></label>
                                <select name="language" class="form-select appearance-none block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding bg-no-repeat border border-solid border-gray-light rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" aria-label="Default select example" disabled>
                                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option class="font-fira-sans" value="<?php echo e($language->name); ?>" <?php echo e($language->name == $user->language ? 'selected' : ''); ?>><?php echo e($language->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3 sm:w-1/2 xxsm:w-full sm:ml-2 xxsm:ml-0">
                                <label for="medical_attention_days" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Medical Attention Days')); ?></label>
                                <input type="number" name="medical_attention_days" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="medical_attention_days" placeholder="<?php echo e(__('Medical Attention Days')); ?>" required />
                                <?php $__errorArgs = ['medical_attention_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    
                            <div class="mb-3 sm:w-1/2 xxsm:w-full sm:ml-2 xxsm:ml-0">
                                <label for="prescription" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Upload Prescription')); ?></label>
                                <input type="file" name="prescription" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="prescription" />
                                <?php $__errorArgs = ['prescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                                   <!-- Issues Field -->
                                   <div class="flex w-full">
                                    <div class="mb-1 w-full">
                                        <label for="gender" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Address')); ?></label>
                                <input type="text" name="address" value="<?php echo e(old('address', $user->address)); ?>" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="gender" placeholder="<?php echo e(__('address')); ?>" />
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                        <!-- Issues Field -->
                        <div class="flex w-full">
                            <div class="mb-1 w-full">
                                <label for="issues" class="form-label inline-block mb-2 text-gray font-fira-sans"><?php echo e(__('Issues')); ?></label>
                                <textarea name="issues" class="form-control block w-full px-3 py-1.5 text-base font-normal text-gray bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray focus:outline-none" id="issues" rows="4" placeholder="<?php echo e(__('Enter your issues here...')); ?>"><?php echo e(old('issues')); ?></textarea>
                                <?php $__errorArgs = ['issues'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-red-500 text-xs mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    
                        <!-- Submit Button -->
                        <div class="flex justify-between w-full xxsm:flex-col msm:flex-row">
                            <div class="w-full mb-4 flex msm:justify-end xxsm:justify-start">
                                <button class="px-6 py-3 font-fira-sans border border-primary text-white bg-primary rounded-md font-medium text-xs leading-tight uppercase focus:outline-none focus:ring-0 transition duration-150 ease-in-out" type="submit" id="button-addon3">
                                    <?php echo e(__('Generate')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('assets/js/intlTelInput.min.js')); ?>"></script>
<script>
    const phoneInputField = document.querySelector(".phone");
    const phoneInput = window.intlTelInput(phoneInputField, {
        preferredCountries: ["us", "co", "in", "de"],
        initialCountry: "in",
        separateDialCode: true,
        utilsScript: "<?php echo e(url('assets/js/utils.js')); ?>",
    });
    phoneInputField.addEventListener("countrychange", function() {
        var phone_code = $('.phone').find('.iti__selected-dial-code').text();
        $('input[name=phone_code]').val('+' + phoneInput.getSelectedCountryData().dialCode);
    });

    $(document).ready(function() {
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var type = $('#imagePreview').attr('data-id');
                    var fileName = document.getElementById("image").value;
                    var idxDot = fileName.lastIndexOf(".") + 1;
                    var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
                    if (extFile == "jpg" || extFile == "jpeg" || extFile == "png") {
                        $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                        $('#imagePreview').hide();
                        $('#imagePreview').fadeIn(650);
                    } else {
                        $('input[type=file]').val('');
                        alert("Only jpg/jpeg and png files are allowed!");
                        if (type == 'add') {
                            $('#imagePreview').css('background-image', 'url()');
                            $('#imagePreview').hide();
                            $('#imagePreview').fadeIn(650);
                        }
                    }
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#image").change(function() {
            readURL(this);
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout', ['activePage' => 'user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u267085990/domains/tsprivatelimited.com/public_html/resources/views/website/eCertificate/certificate_index.blade.php ENDPATH**/ ?>