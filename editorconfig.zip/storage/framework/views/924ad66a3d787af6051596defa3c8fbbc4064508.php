

<?php $__env->startSection('title', __('Medical Certificates')); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <?php echo $__env->make('layout.breadcrumb', [
        'title' => __('Medical Certificates'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session('status')): ?>
        <?php echo $__env->make('superAdmin.auth.status', [
            'status' => session('status')
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <div class="section_body">
        <div class="card">
           
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0">
                        <thead>
                            <tr>
                                <th>
                                    <input name="select_all" value="1" id="master" type="checkbox" />
                                    <label for="master"></label>
                                </th>
                                <th>#</th>
                                <th><?php echo e(__('Patient Name')); ?></th>
                                <th><?php echo e(__('Email')); ?></th>
                                <th><?php echo e(__('Medical Attention Days')); ?></th>
                                <th><?php echo e(__('Date')); ?></th>
                                <th><?php echo e(__('Prescription')); ?></th>
                                <?php if(Gate::check('certificate_edit') || Gate::check('certificate_delete')): ?>
                                    <th><?php echo e(__('Actions')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="id[]" value="<?php echo e($certificate->id); ?>" id="<?php echo e($certificate->id); ?>" data-id="<?php echo e($certificate->id); ?>" class="sub_chk">
                                        <label for="<?php echo e($certificate->id); ?>"></label>
                                    </td>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($certificate->name); ?></td>
                                    <td>
                                        <a href="mailto:<?php echo e($certificate->email); ?>">
                                            <span class="text_transform_none"><?php echo e($certificate->email); ?></span>
                                        </a>
                                    </td>
                                    <td><?php echo e($certificate->medical_attention_days); ?></td>
                                    <td><?php echo e($certificate->created_at->format('d-m-Y')); ?></td>
                                    <td>
                                        <?php if($certificate->prescription): ?>
                                            <a href="<?php echo e(asset($certificate->prescription)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($certificate->prescription)); ?>" alt="Prescription" style="max-width: 100px;">
                                            </a>
                                        <?php else: ?>
                                            <?php echo e(__('No Image')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <?php if(Gate::check('certificate_edit') || Gate::check('certificate_delete')): ?>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('certificate_edit')): ?>
                                            <form action="<?php echo e(route('certificate.send', $certificate->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="text-success" style="border:none; background:none;">
                                                    <i class="fa fa-paper-plane"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('certificate_delete')): ?>
                                            <form action="<?php echo e(route('certificate.delete', $certificate->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="text-danger" style="border:none; background:none;">
                                                    <i class="far fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                                
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card_footer">
                <input type="button" value="Delete Selected" onclick="deleteAll('certificate_all_delete')" class="btn btn-primary">
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout_admin', ['activePage' => 'certificate'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cc\Desktop\FiverrProjects\sushant1441\ondemand-doctor-appointment-booking-saas-marketplace-business-model\doctro_admin_website-v8.2.0\doctro_admin_website\resources\views/superAdmin/certificate/certificate_list.blade.php ENDPATH**/ ?>