<div class="bg-black w-full">
    <div class="xl:w-3/4 mx-auto pt-5">
        <div class="xxsm:mx-5 xl:mx-0 2xl:mx-0">
            <div class="xxsm:pt-5 xxsm:pb-5 justify-between flex sm:flex-row xxsm:flex-col">
                <div>
                    <a href="<?php echo e(url('/')); ?>" class="">
                        <?php if($setting->company_white_logo && file_exists(public_path('images/upload/'.$setting->company_white_logo))): ?>
                        <img src="<?php echo e($setting->companyWhite); ?>" width="150px" height="40px" alt="Logo">
                        <?php else: ?>
                        <img src="<?php echo e(url('/images/upload_empty/logo_white.png')); ?>" class="h-6 mr-3 sm:h-9" alt="Doctro Logo" />
                        <?php endif; ?>
                    </a>
                    <div class="flex pt-5">
                        <a href="<?php echo e($setting->facebook_url); ?>" target="_blank" class=""><i class="fa-brands fa-facebook text-white border rounded-full p-2"></i></a>
                        <a href="<?php echo e($setting->twitter_url); ?>" target="_blank" class="lg:mx-4 md:mx-2 xsm:mx-1 xxsm:mx-1"><i class="fa-brands fa-twitter text-white border rounded-full p-2"></i></a>
                        <a href="<?php echo e($setting->instagram_url); ?>" target="_blank" class=""><i class="fa-brands fa-instagram text-white border rounded-full p-2"></i></a>
                        <a href="<?php echo e($setting->linkdin_url); ?>" target="_blank" class="lg:mx-4 md:mx-2 xsm:mx-1 xxsm:mx-1"><i class="fa-brands fa-linkedin-in text-white border rounded-full p-2"></i></a>
                    </div>
                </div>
                <div class="grid msm:grid-cols-2 gap-10 xsm:grid-cols-1 xxsm:grid-cols-1 mb-5">
                    <div>
                        <h1 class="text-primary font-medium text-lg leading-5 font-fira-sans xxsm:pt-5 sm:pt-0"><?php echo e(__('For Patients')); ?></h1>
                        <div class="2xl:pt-10 xxsm:pt-5">
                            <a href="<?php echo e(url('/show-doctors')); ?>" class="text-white text-sm font-normal leading-4 font-fira-sans pt-10"><?php echo e(__('Search for Doctors')); ?></a>
                        </div>
                        <div class="mt-2">
                            <a href="<?php echo e(url('/all-pharmacies')); ?>" class="text-white text-sm font-normal leading-4 font-fira-sans pt-2"><?php echo e(__('Pharmacy')); ?></a>
                        </div>
                        <div class="mt-2">
                            <a href="<?php echo e(url('/all-labs')); ?>" class="text-white text-sm font-normal leading-4 font-fira-sans pt-2"><?php echo e(__('Lab Tests')); ?></a>
                        </div>
                        <div class="mt-2">
                            <a href="<?php echo e(url('/our-offers')); ?>" class="text-white text-sm font-normal leading-4 font-fira-sans pt-2"><?php echo e(__('Offers')); ?></a>
                        </div>
                        <div class="mt-2">
                            <a href="<?php echo e(url('/our_blogs')); ?>" class="text-white text-sm font-normal leading-4 font-fira-sans pt-2"><?php echo e(__('Blog')); ?></a>
                        </div>
                    </div>
                    <div>
                        <h1 class="text-primary font-medium text-lg leading-5 font-fira-sans msm:pt-5 sm:pt-0"><?php echo e(__('Contact Us:')); ?></h1>
                        <div class="2xl:pt-10 xxsm:pt-5">
                            <a href="tel:<?php echo e($setting->phone); ?>" class="text-white text-sm leading-4 font-fira-sans font-normal underline pt-2"><?php echo e($setting->phone); ?></a>
                        </div>
                        <div class="mt-2">
                            <a href="mailto:<?php echo e($setting->email); ?>" class="text-white text-sm leading-4 font-fira-sans font-normal underline pt-2"><?php echo e($setting->email); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="border-t border-gray pb-5 xxsm:mx-5 xl:mx-0 2xl:mx-0">
            <div class="xxsm:pt-5 justify-between flex sm:flex-row xxsm:flex-col w-[97%]">
                <p class="text-white text-sm font-normal leading-5 font-fira-sans mb-5"><?php echo e(__('Copyright')); ?> &copy; <?php echo e(Carbon\Carbon::now(env('timezone'))->year); ?> <?php echo e(__($setting->business_name)); ?><?php echo e(__(', All rights reserved')); ?> </p>
                <div class="flex flex-row">
                    <div>
                        <a href="<?php echo e(url('about-us')); ?>" class="text-white text-sm font-normal leading-5 font-fira-sans mr-[80px]"><?php echo e(__('About us')); ?></a>
                    </div>
                    <div>
                        <a href="<?php echo e(url('privacy-policy')); ?>" class="text-white text-sm font-normal leading-5 font-fira-sans mr-12"><?php echo e(__('Privacy Policy')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/u267085990/domains/tsprivatelimited.com/public_html/resources/views/layout/partials/footer.blade.php ENDPATH**/ ?>