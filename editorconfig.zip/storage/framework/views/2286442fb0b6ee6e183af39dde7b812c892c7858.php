<?php $__env->startSection('title',__('Forgot Password')); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="d-flex flex-wrap align-items-stretch">
        <div class="col-lg-4 col-md-6 col-12 order-lg-1 min-vh-100 order-2 bg-white">
            <div class="p-4 m-3">
                <?php if(session('status')): ?>
                <?php echo $__env->make('superAdmin.auth.status',[
                'status' => session('status')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php
                $app_logo = App\Models\Setting::first();
                ?>
                <?php if(isset($app_logo->logo)): ?>
                <img src="<?php echo e($app_logo->logo); ?>" alt="logo" width="180" class="mb-5 mt-2">
                <?php else: ?>
                <img src="<?php echo e(url('/images/upload_empty/logo_black.png')); ?>" alt="logo" width="180" class="mb-5 mt-2" />
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e($item); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <h6 class="p-1"><?php echo e(__('Add Email Address To Get New Password')); ?></h6>
                <form action="<?php echo e(url('send_forgot_password')); ?>" method="post" class="myform">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required name="email" value="<?php echo e(old('email')); ?>" type="email">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-block" type="submit"><?php echo e(__('Send Email')); ?></button>
                    </div>
                </form>

                <?php if($from == 'super admin'): ?>
                <div class="text-center mt-5">
                    <a href="<?php echo e(url('/login')); ?>"><?php echo e(__('Remember Password?')); ?></a>
                </div>
                <?php endif; ?>
                <?php if($from =='doctor'): ?>
                <div class="text-center mt-5">
                    <a href="<?php echo e(url('doctor/doctor_login')); ?>"><?php echo e(__('Remember Password?')); ?></a>
                </div>
                <?php endif; ?>
                <?php if($from =='pharmacy'): ?>
                <div class="text-center mt-5">
                    <a href="<?php echo e(url('pharmacy_login')); ?>"><?php echo e(__('Remember Password?')); ?></a>
                </div>
                <?php endif; ?>
                <?php if($from =='lab'): ?>
                <div class="text-center mt-5">
                    <a href="<?php echo e(url('pathologist_login')); ?>"><?php echo e(__('Remember Password?')); ?></a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom" data-background="<?php echo e(url('assets/img/login.png')); ?>">
            <div class="absolute-bottom-left index-2">
                <div class="text-light p-5 pb-2">
                    <div class="mb-5 pb-3">
                        <h1 class="mb-2 display-4 font-weight-bold"><?php echo e(__('Welcome')); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(App\Models\Setting::first()->map_key); ?>&callback=initAutocomplete&libraries=places&v=weekly" async></script>
<script src="<?php echo e(url('assets_admin/js/hospital_map.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mainlayout_admin',['activePage' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cc\Desktop\FiverrProjects\sushant1441\ondemand-doctor-appointment-booking-saas-marketplace-business-model\doctro_admin_website-v8.2.0\doctro_admin_website\resources\views/superAdmin/admin/forgot_password.blade.php ENDPATH**/ ?>